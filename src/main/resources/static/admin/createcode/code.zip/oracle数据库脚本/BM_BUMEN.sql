-- ----------------------------
-- Table structure for "C##FHBOOT"."BM_BUMEN"
-- ----------------------------
-- DROP TABLE "C##FHBOOT"."BM_BUMEN";
CREATE TABLE "C##FHBOOT"."BM_BUMEN" (
	"BNAME" VARCHAR2(255 BYTE) NULL ,
	"NAME" VARCHAR2(100 BYTE) NOT NULL,
	"PARENT_ID" VARCHAR2(100 BYTE) NOT NULL,
	"BUMEN_ID" VARCHAR2(100 BYTE) NOT NULL 
)
LOGGING
NOCOMPRESS
NOCACHE
;

COMMENT ON COLUMN "C##FHBOOT"."BM_BUMEN"."BNAME" IS '部门名称';
COMMENT ON COLUMN "C##FHBOOT"."BM_BUMEN"."BUMEN_ID" IS 'ID';

-- ----------------------------
-- Indexes structure for table BM_BUMEN
-- ----------------------------

-- ----------------------------
-- Checks structure for table "C##FHBOOT"."BM_BUMEN"

-- ----------------------------

ALTER TABLE "C##FHBOOT"."BM_BUMEN" ADD CHECK ("BUMEN_ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table "C##FHBOOT"."BM_BUMEN"
-- ----------------------------
ALTER TABLE "C##FHBOOT"."BM_BUMEN" ADD PRIMARY KEY ("BUMEN_ID");
