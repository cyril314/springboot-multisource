
SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `BM_BUMEN`
-- ----------------------------
DROP TABLE IF EXISTS `BM_BUMEN`;
CREATE TABLE `BM_BUMEN` (
 		`BUMEN_ID` varchar(100) NOT NULL,
 		`PARENT_ID` varchar(100) NOT NULL,
		`NAME` varchar(100) NOT NULL,
		`BNAME` varchar(255) DEFAULT NULL COMMENT '部门名称',
  		PRIMARY KEY (`BUMEN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
